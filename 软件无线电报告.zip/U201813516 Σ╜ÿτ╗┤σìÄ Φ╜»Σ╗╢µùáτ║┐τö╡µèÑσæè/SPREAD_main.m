clear
close all

%%%%%%%%%%%ϵͳ���������

% �ź��ز�Ƶ��
sys_param.center_freq  = 1000;
% �źű�������
sys_param.symbol_rate = 100;
% �źŲ���Ƶ��
sys_param.sample_freq = 40000;
% ����������(dB)
sys_param.SNR = 20;
%��������
input_data = randint(1,10,[0,1]);
%α��
code_len=11;
code = [1 1 1 0 0 0 1 0 0 1 0];
%���Ƴ�ʼ��λ
fai=0;

figure(1)
stem(input_data);
title('input data');

symbol_len=floor(sys_param.sample_freq/(sys_param.symbol_rate));
len=length(input_data);
input_signal=zeros(1,len*symbol_len);
t=0;
for k=1:len
    for l=1:symbol_len
        t=t+1;
        input_signal(t)=(input_data(k)*2-1) * sin(2*pi*t*sys_param.center_freq/sys_param.sample_freq+fai);
    end
end


figure(2)
plot(1:length(input_signal),input_signal);
title('modulated signal (input)');

fft_data=abs(fft(input_signal));
figure(3)
plot(1:length(input_signal),[fft_data(2001:4000),fft_data(1:2000)]);
title('modulated signal fourier (input)');
%%%%%%%%  ����
%��Ƶ
spread_data=zeros(1,length(input_data)*code_len);
for k=1:length(input_data)
    for l=1:code_len
        spread_data(code_len*(k-1)+l)=xor(input_data(k),code(l));
    end
end

figure(4)
stem(spread_data);
title('multi data');

%����
symbol_len=floor(sys_param.sample_freq/(sys_param.symbol_rate*code_len));

len=length(spread_data);
modulated_signal=zeros(1,len*symbol_len);
t=0;
for k=1:len
    for l=1:symbol_len
        t=t+1;
        modulated_signal(t)=(spread_data(k)*2-1) * sin(2*pi*t*sys_param.center_freq/sys_param.sample_freq+fai);
    end
end

figure(5)
plot(1:length(modulated_signal),modulated_signal);
title('modulated signal (spread)');
fft_data=abs(fft(modulated_signal));
figure(6)
plot(1:length(modulated_signal),[fft_data(1981:3960),fft_data(1:1980)]);
title('modulated signal fourier (spread)');


%%%%%%%  �ŵ�
%��������
tx_signal = awgn(modulated_signal,sys_param.SNR);
figure(7)
plot(1:length(tx_signal),tx_signal);
title('noise-channel');

%%%%%%%  ����
%��Ƶ
recv_signal=zeros(1,length(input_data)*code_len);
t=0;
for k=1:len
    for l=1:symbol_len
        t=t+1;
        recv_signal(t)=tx_signal(t) * sin(2*pi*t*sys_param.center_freq/sys_param.sample_freq+fai);
    end
end
%�˲�
LowpassSig=filter(lowpass2,recv_signal);

figure(8)
plot(1:length(LowpassSig),LowpassSig);
title('LowpassSig');

%����
decode_signal=zeros(1,length(LowpassSig));
code_sig=rectpulse(code,symbol_len);
t=0;
for k=1:length(input_data)
    for l=1:symbol_len*code_len
        t=t+1;
        decode_signal(t)=LowpassSig(t)*(2*code_sig(l)-1);
    end
end
figure(9)
plot(1:length(decode_signal),decode_signal);
title('DecodeSig');

%����
recv_data=zeros(1,length(input_data));
for k=1:length(input_data)
    sample=decode_signal(k*symbol_len*code_len)*2;
    if sample>0
       recv_data(k)=0;
    else
       recv_data(k)=1;
    end
end

%%%%%%%%%���ͳ��
error=0;
for k=1:length(input_data)
    if recv_data(k)~=input_data(k)
        error=error+1;
    end
end





