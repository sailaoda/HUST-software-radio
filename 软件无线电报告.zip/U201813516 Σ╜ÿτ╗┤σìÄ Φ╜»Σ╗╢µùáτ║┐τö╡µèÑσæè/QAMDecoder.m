function [ decode_data ] = QAMDecoder(sampled_signal,sys_param )
symbol_len=sys_param.sample_freq/sys_param.symbol_rate;
len=2000;
%????
Sig1=[];
Sig2=[];
for k = 1:length(sampled_signal)
    Sig1=[Sig1,sampled_signal(k)*cos(2*pi*sys_param.carrier_freq/sys_param.sample_freq*k)];
    Sig2=[Sig2,sampled_signal(k)*sin(2*pi*sys_param.carrier_freq/sys_param.sample_freq*k)*(-1)];
end
t = [1:length(sampled_signal)];
figure(6)
plot(t,Sig1);
title('Sig1-carrier');

figure(7)
plot(t,Sig2);
title('Sig2-carrier');
%????

LowpassSig1=filter(lowpass,Sig1);
LowpassSig2=filter(lowpass,Sig2);

t = [1:length(sampled_signal)];
figure(8)
plot(t,LowpassSig1);
title('Sig1-lowpass');

figure(9)
plot(t,LowpassSig2);
title('Sig2-lowpass');

%4????
X_r=[];
Y_r=[];
for t=1:len/4
    X_r=[X_r,LowpassSig1(symbol_len*t)*2];
    Y_r=[Y_r,LowpassSig2(symbol_len*t)*2];
end
figure(10)
plot(X_r,Y_r,'.b');
title('QAM');

%4-2????
a_r=[];
b_r=[];
c_r=[];
d_r=[];
for t=1:len/4
    if (X_r(t)>2)
        a_r=[a_r,1];
        c_r=[c_r,1];
    elseif (X_r(t)>0)
        a_r=[a_r,1];
        c_r=[c_r,0];
    elseif (X_r(t)>-2)
        a_r=[a_r,0];
        c_r=[c_r,1];
    elseif (X_r(t)<=-2)
        a_r=[a_r,0];
        c_r=[c_r,0];
    end
    if (Y_r(t)>2)
        b_r=[b_r,1];
        d_r=[d_r,1];
    elseif (Y_r(t)>0)
        b_r=[b_r,1];
        d_r=[d_r,0];
    elseif (Y_r(t)>-2)
        b_r=[b_r,0];
        d_r=[d_r,1];
    elseif (Y_r(t)<=-2)
        b_r=[b_r,0];
        d_r=[d_r,0];
    end
end

%??
decode_data=[];
for t=1:len/4
    decode_data=[decode_data,a_r(t),b_r(t),c_r(t),d_r(t)];
end
