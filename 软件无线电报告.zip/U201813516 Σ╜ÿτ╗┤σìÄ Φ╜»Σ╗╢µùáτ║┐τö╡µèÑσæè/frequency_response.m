function []=frequency_response_deshift(data,tit,col)%qpsk_bit 128
    N=256;
    data_p = zeros(1,256);
    data_p(65:192) = data;
    data_p = awgn(data_p,50);
    data_p = ifft(data_p,256);
    delta_f=15*10^3; %subcarrier spacing    
    fs=N*delta_f; %sampling frequency
    ts=1/fs; %sampling period    OFDM��Ԫ���� N*Ts
    data_sampled=fft(data_p,1024)*ts;
    data_sampled = 10*log10(data_sampled*10^3);
    data_ss=fftshift(data_sampled);
    len=length(data_sampled)-1;
    ff=fs/len;
    f=0:ff:fs;
    %stem(real(Hcentered),imag(Hcentered))
    plot(f,real(data_sampled),col)
    title(tit);
    xlim([-10*delta_f,fs+10*delta_f]);
    xlabel('frequency');
    ylabel('frequency response');
end

