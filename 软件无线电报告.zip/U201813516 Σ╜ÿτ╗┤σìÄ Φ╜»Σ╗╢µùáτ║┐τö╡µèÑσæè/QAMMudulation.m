function [modulated_signal] = QAMMudulation(input_data,sys_param)
% ??4???
input_data = [input_data , zeros(1,4-mod(length(input_data),4)) ];
% ??????
len = length(input_data);
% ???????(??)
symbol_len = sys_param.sample_freq/sys_param.symbol_rate;
% ????
ac=[];
bd=[];
for k=1:len
    if mod(k,2)==1
        ac=[ac,input_data(k)];
    end
    if mod(k,2)==0
        bd=[bd,input_data(k)];
    end
end
% 2-4????
X=[];
Y=[];
for k=1:len/4
    X=[X,(ac(2*k-1)*4+ac(2*k)*2-3)];
    Y=[Y,(bd(2*k-1)*4+bd(2*k)*2-3)];
end
% ????
X_t=[];
Y_t=[];
for k = 1:len/4
    for t = 1:symbol_len
        X_t=[X_t,X(k)*cos(2*pi*sys_param.carrier_freq/sys_param.sample_freq*t)];
        Y_t=[Y_t,Y(k)*sin(2*pi*sys_param.carrier_freq/sys_param.sample_freq*t)*(-1)];
    end
end
t=[1:symbol_len*len/4];
figure(1)
plot(t,X_t);
title('sin');

figure(2)
plot(t,Y_t);
title('cos');
% ??
modulated_signal=X_t+Y_t;
figure(3)
plot(t,modulated_signal);
title('QAM-time');

fft_signal=fft(modulated_signal);
figure(4)
plot(t,fft_signal);
title('QAM-frequecy');

end

